class CalcController{
	constructor(){

		this._operation = [];
    this._locale = 'pt-BR';
		this._displayCalcEl = document.querySelector("#display");
		this._dateEl = document.querySelector("#data");
		this._timeE1 = document.querySelector("#hora");
		//this._displayCalc = "";
		this._currentDate;
		this.initialize();
		this.initButtonsEvents();
		
		
	}

	initialize(){

		setInterval(() => {

			this.displayDate = this.currendate.toLocaleDateString(this._locale,{
				day: "2-digit",
				month: "long",
				year: "numeric",
			});
			this.dispalyTime = this.currendate.toLocaleTimeString(this._locale);

		}, 1000);
	}

	addEventListenerAll(element, events,fn){

		events.split(' ').forEach(event => {
				
			   element.addEventListener(events, fn, false);

		});
		
	}

	clearAll(){

		this._operation = [];

	}

	clearEntry(){
		
		//o pop é reponsavel por cancelar o ultimo valor
		this._operation.pop();

	}

	getLastOperation(){

   return this._operation[this._operation.lenght-1];

	}

	addOperation(value){
		
		//push serve pra add + 1 informação
		this._operation.push(value);

		console.log(this.operation);
	}

	setError(){

		this.displayCalc = "Error";
	}

	execBtn(value){

		switch(value){

			case 'ac' :
			   
			break;
		

		case 'c' :
		    
    break;


    case 'soma' :
      
   break;

    case 'subtracao' :
        
    break;


    case 'divisao' :
        
    break;


    case 'multiplicacao' :
       
    break;


    case 'porcento' :
       
    break;


    case 'igual' :
       
		break;

		case 'ponto' :

		break;

		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
				
		    this.operation(parseInt(value));
		    break;


		

 default:
				this.setError();
				break;		


	}
		}
		
		

	 initButtonsEvents(){

		let buttons =	document.querySelectorAll("#buttons > g, #parts > g");

		buttons.forEach((btn, index)=>{

			this.addEventListenerAll(btn,"click drag", e => {

			let textBtn	= btn.className.baseVal.replace("btn-","");

      this.execBtn(textBtn);

			});

		  	this.addEventListenerAll(btn,"mouseover mouseup mousedown", e => {

					btn.style.cursor = "pointer";
			}) 
				
		});
		

		};

	get dispalyTime(){
		return this._timeE1.innerHTML;
    }

	set dispalyTime(value){
		return this._timeE1.innerHTML = value;


	}

	get displayDate(){
		return this._dateEl.innerHTML;

	}

	set displayDate(value){
		return this._dateEl.innerHTML = value;

	}

	get dispalyCalc(){
		return this._displayCalcEl.innerHTML;
	}

	set dispalyCalc(valor){
		this._displayCalcEl = value;
	}

	get currendate(){
		return new Date();
	}

	set currentDate(valor){
		this._currentDate = value;
	}
}
